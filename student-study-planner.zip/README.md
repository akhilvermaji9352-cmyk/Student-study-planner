# Smart Student Study Planner

npm install
npm run dev
