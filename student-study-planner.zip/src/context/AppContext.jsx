import { createContext, useContext, useEffect, useState } from 'react';

export const SUBJECTS = ['Data Structures', 'DBMS', 'Operating Systems', 'Computer Networks', 'Web Technology'];
export const DAYS = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
const KEY = 'ssp_data_v1';
export const uid = () => Math.random().toString(36).slice(2, 9);
export const dateStr = (offset = 0) => {
  const x = new Date(); x.setDate(x.getDate() + offset);
  return `${x.getFullYear()}-${String(x.getMonth() + 1).padStart(2, '0')}-${String(x.getDate()).padStart(2, '0')}`;
};

const empty = () => ({ tasks: [], sessions: [], logs: [], activity: [],
  profile: { name: 'Student', course: '', college: '', goal: 3 }, theme: 'light' });

const sample = () => ({
  tasks: [
    { id: uid(), title: 'Solve linked list problems', subject: 'Data Structures', priority: 'High', deadline: dateStr(1), done: false },
    { id: uid(), title: 'ER diagram assignment', subject: 'DBMS', priority: 'Medium', deadline: dateStr(3), done: false },
    { id: uid(), title: 'Revise process scheduling', subject: 'Operating Systems', priority: 'High', deadline: dateStr(-1), done: true },
    { id: uid(), title: 'Subnetting practice sheet', subject: 'Computer Networks', priority: 'Low', deadline: dateStr(6), done: false },
    { id: uid(), title: 'Build React mini project', subject: 'Web Technology', priority: 'High', deadline: dateStr(9), done: false },
  ],
  sessions: [
    { id: uid(), day: 'Monday', subject: 'Data Structures', start: '18:00', end: '19:30' },
    { id: uid(), day: 'Tuesday', subject: 'DBMS', start: '17:00', end: '18:30' },
    { id: uid(), day: 'Wednesday', subject: 'Operating Systems', start: '19:00', end: '20:00' },
    { id: uid(), day: 'Friday', subject: 'Web Technology', start: '16:00', end: '18:00' },
  ],
  logs: [0, 1, 2, 3, 4, 5, 6].map((i) => ({ id: uid(), subject: SUBJECTS[i % 5], minutes: 25 * (1 + (i % 4)), date: dateStr(-i) })),
  activity: [{ id: uid(), text: 'Welcome! Sample data loaded.', time: new Date().toLocaleString() }],
  profile: { name: 'Aarav Sharma', course: 'B.Tech CSE - 3rd Year', college: 'Your College Name', goal: 3 },
  theme: 'light',
});

const Ctx = createContext();
export const useApp = () => useContext(Ctx);

export function AppProvider({ children }) {
  const [data, setData] = useState(() => {
    try { return JSON.parse(localStorage.getItem(KEY)) || sample(); } catch { return sample(); }
  });
  useEffect(() => { localStorage.setItem(KEY, JSON.stringify(data)); }, [data]);
  useEffect(() => { document.documentElement.dataset.theme = data.theme; }, [data.theme]);

  const log = (d, text) => ({ ...d, activity: [{ id: uid(), text, time: new Date().toLocaleString() }, ...d.activity].slice(0, 15) });
  const set = (fn) => setData((d) => fn(d));

  const api = {
    ...data,
    addTask: (t) => set((d) => log({ ...d, tasks: [{ ...t, id: uid(), done: false }, ...d.tasks] }, `Added task "${t.title}"`)),
    updateTask: (id, t) => set((d) => log({ ...d, tasks: d.tasks.map((x) => (x.id === id ? { ...x, ...t } : x)) }, `Updated task "${t.title}"`)),
    deleteTask: (id) => set((d) => log({ ...d, tasks: d.tasks.filter((x) => x.id !== id) }, 'Deleted a task')),
    toggleTask: (id) => set((d) => {
      const t = d.tasks.find((x) => x.id === id);
      return log({ ...d, tasks: d.tasks.map((x) => (x.id === id ? { ...x, done: !x.done } : x)) },
        `${t.done ? 'Reopened' : 'Completed'} "${t.title}"`);
    }),
    addSession: (s) => set((d) => log({ ...d, sessions: [...d.sessions, { ...s, id: uid() }] }, `Planned ${s.subject} on ${s.day}`)),
    updateSession: (id, s) => set((d) => log({ ...d, sessions: d.sessions.map((x) => (x.id === id ? { ...x, ...s } : x)) }, `Updated ${s.subject} session`)),
    deleteSession: (id) => set((d) => log({ ...d, sessions: d.sessions.filter((x) => x.id !== id) }, 'Deleted a study session')),
    addLog: (subject, minutes) => set((d) => log({ ...d, logs: [...d.logs, { id: uid(), subject, minutes, date: dateStr() }] }, `Finished ${minutes} min of ${subject}`)),
    setProfile: (p) => set((d) => ({ ...d, profile: { ...d.profile, ...p } })),
    toggleTheme: () => set((d) => ({ ...d, theme: d.theme === 'light' ? 'dark' : 'light' })),
    clearData: () => setData({ ...empty(), theme: data.theme }),
    loadSample: () => setData({ ...sample(), theme: data.theme }),
  };
  return <Ctx.Provider value={api}>{children}</Ctx.Provider>;
}
