import { ListChecks, CheckCircle2, Hourglass, Clock, TrendingUp } from 'lucide-react';
import StatCard from '../components/StatCard.jsx';
import { useApp } from '../context/AppContext.jsx';

export default function Dashboard() {
  const { tasks, logs, activity, profile } = useApp();
  const done = tasks.filter((t) => t.done).length;
  const hours = (logs.reduce((a, l) => a + l.minutes, 0) / 60).toFixed(1);
  const pct = tasks.length ? Math.round((done / tasks.length) * 100) : 0;
  return (
    <>
      <div className="banner"><h2>Welcome back, {profile.name}! 👋</h2><p>You have {tasks.length - done} pending task(s). Keep going!</p></div>
      <div className="stats">
        <StatCard icon={ListChecks} label="Total Tasks" value={tasks.length} />
        <StatCard icon={CheckCircle2} label="Completed" value={done} color="#10b981" />
        <StatCard icon={Hourglass} label="Pending" value={tasks.length - done} color="#f59e0b" />
        <StatCard icon={Clock} label="Study Hours" value={hours} color="#3b82f6" />
        <StatCard icon={TrendingUp} label="Progress" value={`${pct}%`} color="#8b5cf6" />
      </div>
      <div className="card">
        <h3>Progress</h3><div className="bar"><div style={{ width: `${pct}%` }} /></div>
        <h3 style={{ marginTop: 20 }}>Recent Activities</h3>
        {activity.length === 0 && <p className="muted">No activity yet.</p>}
        {activity.slice(0, 6).map((a) => <div className="row" key={a.id}><span>{a.text}</span><small className="muted">{a.time}</small></div>)}
      </div>
    </>
  );
}
