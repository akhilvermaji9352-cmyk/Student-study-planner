import { useState } from 'react';
import { Plus, Search } from 'lucide-react';
import TaskCard from '../components/TaskCard.jsx';
import { useApp, SUBJECTS } from '../context/AppContext.jsx';

const blank = { title: '', subject: SUBJECTS[0], priority: 'Medium', deadline: '' };

export default function Tasks() {
  const { tasks, addTask, updateTask, deleteTask, toggleTask } = useApp();
  const [form, setForm] = useState(blank);
  const [editId, setEditId] = useState(null);
  const [q, setQ] = useState(''), [status, setStatus] = useState('all'), [prio, setPrio] = useState('all');
  const ch = (k) => (e) => setForm({ ...form, [k]: e.target.value });

  const submit = (e) => {
    e.preventDefault();
    if (!form.title.trim()) return;
    editId ? updateTask(editId, form) : addTask(form);
    setForm(blank); setEditId(null);
  };
  const shown = tasks.filter((t) => t.title.toLowerCase().includes(q.toLowerCase())
    && (status === 'all' || (status === 'done') === t.done)
    && (prio === 'all' || t.priority === prio));

  return (
    <>
      <form className="card form" onSubmit={submit}>
        <input placeholder="Task title" value={form.title} onChange={ch('title')} required />
        <select value={form.subject} onChange={ch('subject')}>{SUBJECTS.map((s) => <option key={s}>{s}</option>)}</select>
        <select value={form.priority} onChange={ch('priority')}>{['High', 'Medium', 'Low'].map((p) => <option key={p}>{p}</option>)}</select>
        <input type="date" value={form.deadline} onChange={ch('deadline')} />
        <button className="btn"><Plus size={16} /> {editId ? 'Update' : 'Add Task'}</button>
        {editId && <button type="button" className="btn ghost" onClick={() => { setEditId(null); setForm(blank); }}>Cancel</button>}
      </form>
      <div className="card form">
        <div className="search"><Search size={16} /><input placeholder="Search tasks..." value={q} onChange={(e) => setQ(e.target.value)} /></div>
        <select value={status} onChange={(e) => setStatus(e.target.value)}><option value="all">All status</option><option value="pending">Pending</option><option value="done">Completed</option></select>
        <select value={prio} onChange={(e) => setPrio(e.target.value)}><option value="all">All priority</option><option>High</option><option>Medium</option><option>Low</option></select>
      </div>
      {shown.length === 0 && <p className="muted">No tasks found.</p>}
      {shown.map((t) => (
        <TaskCard key={t.id} task={t} onToggle={() => toggleTask(t.id)} onDelete={() => deleteTask(t.id)}
          onEdit={() => { setEditId(t.id); setForm({ title: t.title, subject: t.subject, priority: t.priority, deadline: t.deadline }); window.scrollTo(0, 0); }} />
      ))}
    </>
  );
}
