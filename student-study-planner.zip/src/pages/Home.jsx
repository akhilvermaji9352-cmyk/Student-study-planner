import { Link } from 'react-router-dom';
import { ListChecks, CalendarClock, Timer, BarChart3, ArrowRight, BookOpenCheck } from 'lucide-react';

const feats = [
  [ListChecks, 'Task Manager', 'Add, edit, filter and complete tasks with deadlines and priorities.'],
  [CalendarClock, 'Study Planner', 'Weekly timetable with subject-wise study sessions.'],
  [Timer, 'Pomodoro Timer', '25/5 focus cycles with automatic session tracking.'],
  [BarChart3, 'Progress Charts', 'Chart.js graphs for weekly hours and subject performance.'],
];

export default function Home() {
  return (
    <div className="landing">
      <nav className="land-nav"><b className="brand-light"><BookOpenCheck size={24} /> StudyPlanner</b><Link to="/dashboard" className="btn light">Open App</Link></nav>
      <section className="hero">
        <h1>Smart Student Study Planner</h1>
        <p>Plan smarter, focus deeper and track your academic progress, all in one place. Your data stays in your browser.</p>
        <Link to="/dashboard" className="btn light big">Get Started <ArrowRight size={18} /></Link>
      </section>
      <section className="features">
        {feats.map(([Icon, t, d]) => (
          <div className="card feat" key={t}><Icon size={30} color="#6366f1" /><h3>{t}</h3><p className="muted">{d}</p></div>
        ))}
      </section>
      <footer>B.Tech 3rd Year Mini Project · React + Vite · LocalStorage</footer>
    </div>
  );
}
