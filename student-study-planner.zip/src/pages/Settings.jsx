import { Trash2, RefreshCw } from 'lucide-react';
import { useApp } from '../context/AppContext.jsx';

export default function Settings() {
  const { theme, toggleTheme, clearData, loadSample } = useApp();
  return (
    <div className="card profile">
      <div className="row"><span>Dark mode</span><button className="btn" onClick={toggleTheme}>{theme === 'dark' ? 'Switch to Light' : 'Switch to Dark'}</button></div>
      <div className="row"><span>Reload sample data</span><button className="btn ghost" onClick={() => window.confirm('Replace current data with sample data?') && loadSample()}><RefreshCw size={16} /> Load</button></div>
      <div className="row"><span>Clear all saved data</span><button className="btn danger-btn" onClick={() => window.confirm('Delete all tasks, sessions and logs?') && clearData()}><Trash2 size={16} /> Clear</button></div>
      <p className="muted">All data is stored only in this browser (LocalStorage). There is no login or server.</p>
    </div>
  );
}
