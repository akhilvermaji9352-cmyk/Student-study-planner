import { Bar, Doughnut } from 'react-chartjs-2';
import { Chart as ChartJS, CategoryScale, LinearScale, BarElement, ArcElement, Tooltip, Legend } from 'chart.js';
import { useApp, SUBJECTS, dateStr } from '../context/AppContext.jsx';

ChartJS.register(CategoryScale, LinearScale, BarElement, ArcElement, Tooltip, Legend);
const COLORS = ['#6366f1', '#3b82f6', '#8b5cf6', '#10b981', '#f59e0b'];

export default function Progress() {
  const { tasks, logs } = useApp();
  const last7 = [6, 5, 4, 3, 2, 1, 0].map((i) => dateStr(-i));
  const daily = last7.map((d) => +(logs.filter((l) => l.date === d).reduce((a, l) => a + l.minutes, 0) / 60).toFixed(2));
  const weekTotal = daily.reduce((a, b) => a + b, 0).toFixed(1);
  const bySubject = SUBJECTS.map((s) => logs.filter((l) => l.subject === s).reduce((a, l) => a + l.minutes, 0));
  const perf = SUBJECTS.map((s) => { const t = tasks.filter((x) => x.subject === s); return t.length ? Math.round((t.filter((x) => x.done).length / t.length) * 100) : 0; });
  const pct = tasks.length ? Math.round((tasks.filter((t) => t.done).length / tasks.length) * 100) : 0;
  const opts = { responsive: true, plugins: { legend: { display: false } } };

  return (
    <>
      <div className="stats">
        <div className="card"><p className="muted">Today</p><h3>{daily[6]} h</h3></div>
        <div className="card"><p className="muted">This week</p><h3>{weekTotal} h</h3></div>
        <div className="card"><p className="muted">Tasks completed</p><h3>{pct}%</h3></div>
      </div>
      <div className="grid-2">
        <div className="card"><h3>Daily study hours (last 7 days)</h3>
          <Bar options={opts} data={{ labels: last7.map((d) => d.slice(5)), datasets: [{ data: daily, backgroundColor: '#6366f1', borderRadius: 6 }] }} /></div>
        <div className="card"><h3>Time per subject</h3>
          <Doughnut data={{ labels: SUBJECTS, datasets: [{ data: bySubject, backgroundColor: COLORS }] }} options={{ responsive: true }} /></div>
        <div className="card"><h3>Subject-wise task completion (%)</h3>
          <Bar options={{ ...opts, scales: { y: { max: 100, beginAtZero: true } } }} data={{ labels: SUBJECTS, datasets: [{ data: perf, backgroundColor: COLORS, borderRadius: 6 }] }} /></div>
      </div>
    </>
  );
}
