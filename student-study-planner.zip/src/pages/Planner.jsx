import { useState } from 'react';
import { Plus, Pencil, Trash2 } from 'lucide-react';
import { useApp, SUBJECTS, DAYS } from '../context/AppContext.jsx';

const blank = { day: 'Monday', subject: SUBJECTS[0], start: '18:00', end: '19:00' };
const todayName = DAYS[(new Date().getDay() + 6) % 7];

export default function Planner() {
  const { sessions, addSession, updateSession, deleteSession } = useApp();
  const [form, setForm] = useState(blank);
  const [editId, setEditId] = useState(null);
  const ch = (k) => (e) => setForm({ ...form, [k]: e.target.value });
  const submit = (e) => {
    e.preventDefault();
    if (form.end <= form.start) return alert('End time must be after start time');
    editId ? updateSession(editId, form) : addSession(form);
    setForm(blank); setEditId(null);
  };
  const byDay = (d) => sessions.filter((s) => s.day === d).sort((a, b) => a.start.localeCompare(b.start));
  const todays = byDay(todayName);

  return (
    <>
      <form className="card form" onSubmit={submit}>
        <select value={form.day} onChange={ch('day')}>{DAYS.map((d) => <option key={d}>{d}</option>)}</select>
        <select value={form.subject} onChange={ch('subject')}>{SUBJECTS.map((s) => <option key={s}>{s}</option>)}</select>
        <input type="time" value={form.start} onChange={ch('start')} required />
        <input type="time" value={form.end} onChange={ch('end')} required />
        <button className="btn"><Plus size={16} /> {editId ? 'Update' : 'Add Session'}</button>
      </form>
      <div className="card">
        <h3>Today's schedule ({todayName})</h3>
        {todays.length === 0 && <p className="muted">No sessions planned today.</p>}
        {todays.map((s) => <div className="row" key={s.id}><span>{s.subject}</span><span className="tag">{s.start} - {s.end}</span></div>)}
      </div>
      <h3 style={{ margin: '20px 0 10px' }}>Weekly timetable</h3>
      <div className="week">
        {DAYS.map((d) => (
          <div className="card day" key={d}>
            <h4>{d}</h4>
            {byDay(d).length === 0 && <small className="muted">Free</small>}
            {byDay(d).map((s) => (
              <div className="slot" key={s.id}>
                <b>{s.subject}</b><small>{s.start} - {s.end}</small>
                <div>
                  <button className="icon-btn" onClick={() => { setEditId(s.id); setForm({ day: s.day, subject: s.subject, start: s.start, end: s.end }); window.scrollTo(0, 0); }}><Pencil size={14} /></button>
                  <button className="icon-btn danger" onClick={() => deleteSession(s.id)}><Trash2 size={14} /></button>
                </div>
              </div>
            ))}
          </div>
        ))}
      </div>
    </>
  );
}
