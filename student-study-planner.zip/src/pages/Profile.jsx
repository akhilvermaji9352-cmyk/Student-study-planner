import { useState } from 'react';
import { Save } from 'lucide-react';
import { useApp } from '../context/AppContext.jsx';

export default function Profile() {
  const { profile, setProfile } = useApp();
  const [f, setF] = useState(profile);
  const [saved, setSaved] = useState(false);
  const ch = (k) => (e) => { setF({ ...f, [k]: e.target.value }); setSaved(false); };
  return (
    <div className="card profile">
      <div className="avatar big">{f.name.charAt(0).toUpperCase() || 'S'}</div>
      <label>Name<input value={f.name} onChange={ch('name')} /></label>
      <label>Course<input value={f.course} onChange={ch('course')} /></label>
      <label>College<input value={f.college} onChange={ch('college')} /></label>
      <label>Daily study goal (hours)<input type="number" min="1" max="16" value={f.goal} onChange={ch('goal')} /></label>
      <button className="btn" onClick={() => { setProfile({ ...f, name: f.name.trim() || 'Student' }); setSaved(true); }}><Save size={16} /> Save</button>
      {saved && <p className="muted">Profile saved ✔</p>}
    </div>
  );
}
