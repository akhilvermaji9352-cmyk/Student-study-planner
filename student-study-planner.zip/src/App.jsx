import { useState } from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import Sidebar from './components/Sidebar.jsx';
import Header from './components/Header.jsx';
import Calendar from './components/Calendar.jsx';
import PomodoroTimer from './components/PomodoroTimer.jsx';
import Home from './pages/Home.jsx';
import Dashboard from './pages/Dashboard.jsx';
import Tasks from './pages/Tasks.jsx';
import Planner from './pages/Planner.jsx';
import Progress from './pages/Progress.jsx';
import Profile from './pages/Profile.jsx';
import Settings from './pages/Settings.jsx';

function Layout({ children, title }) {
  const [open, setOpen] = useState(false);
  return (
    <div className="app">
      <Sidebar open={open} close={() => setOpen(false)} />
      <main className="main">
        <Header title={title} toggleMenu={() => setOpen(!open)} />
        <div className="page">{children}</div>
      </main>
    </div>
  );
}
const L = (title, el) => <Layout title={title}>{el}</Layout>;

export default function App() {
  return (
    <Routes>
      <Route path="/" element={<Home />} />
      <Route path="/dashboard" element={L('Dashboard', <Dashboard />)} />
      <Route path="/tasks" element={L('Task Manager', <Tasks />)} />
      <Route path="/planner" element={L('Study Planner', <Planner />)} />
      <Route path="/calendar" element={L('Calendar', <Calendar />)} />
      <Route path="/timer" element={L('Pomodoro Timer', <PomodoroTimer />)} />
      <Route path="/progress" element={L('Progress Tracker', <Progress />)} />
      <Route path="/profile" element={L('Profile', <Profile />)} />
      <Route path="/settings" element={L('Settings', <Settings />)} />
      <Route path="*" element={<Navigate to="/" />} />
    </Routes>
  );
}
