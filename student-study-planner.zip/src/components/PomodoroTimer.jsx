import { useEffect, useState } from 'react';
import { Play, Pause, RotateCcw } from 'lucide-react';
import { useApp, SUBJECTS, dateStr } from '../context/AppContext.jsx';

const LEN = { focus: 25 * 60, break: 5 * 60 };

export default function PomodoroTimer() {
  const { addLog, logs } = useApp();
  const [mode, setMode] = useState('focus');
  const [left, setLeft] = useState(LEN.focus);
  const [running, setRunning] = useState(false);
  const [subject, setSubject] = useState(SUBJECTS[0]);

  useEffect(() => {
    if (!running) return;
    const id = setInterval(() => setLeft((s) => s - 1), 1000);
    return () => clearInterval(id);
  }, [running]);

  useEffect(() => {
    if (left > 0) return;
    if (mode === 'focus') addLog(subject, 25);
    const next = mode === 'focus' ? 'break' : 'focus';
    setMode(next); setLeft(LEN[next]); setRunning(false);
  }, [left]); // eslint-disable-line

  const switchMode = (m) => { setMode(m); setLeft(LEN[m]); setRunning(false); };
  const mm = String(Math.floor(left / 60)).padStart(2, '0'), ss = String(left % 60).padStart(2, '0');
  const pct = ((LEN[mode] - left) / LEN[mode]) * 100;
  const todayLogs = logs.filter((l) => l.date === dateStr());

  return (
    <div className="card timer">
      <div className="seg">
        <button className={mode === 'focus' ? 'on' : ''} onClick={() => switchMode('focus')}>Focus 25</button>
        <button className={mode === 'break' ? 'on' : ''} onClick={() => switchMode('break')}>Break 5</button>
      </div>
      <div className="ring" style={{ background: `conic-gradient(var(--primary) ${pct}%, var(--border) 0)` }}>
        <div className="ring-in">{mm}:{ss}</div>
      </div>
      <select value={subject} onChange={(e) => setSubject(e.target.value)} disabled={running}>
        {SUBJECTS.map((s) => <option key={s}>{s}</option>)}
      </select>
      <div className="btn-row">
        <button className="btn" onClick={() => setRunning(!running)}>{running ? <><Pause size={16} /> Pause</> : <><Play size={16} /> Start</>}</button>
        <button className="btn ghost" onClick={() => { setLeft(LEN[mode]); setRunning(false); }}><RotateCcw size={16} /> Reset</button>
      </div>
      <p className="muted">Sessions completed today: <b>{todayLogs.length}</b> ({todayLogs.reduce((a, l) => a + l.minutes, 0)} min)</p>
    </div>
  );
}
