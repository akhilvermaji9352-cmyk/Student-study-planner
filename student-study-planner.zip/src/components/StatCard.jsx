export default function StatCard({ icon: Icon, label, value, color = '#6366f1' }) {
  return (
    <div className="card stat">
      <div className="stat-icon" style={{ background: color }}><Icon size={22} color="#fff" /></div>
      <div><p className="muted">{label}</p><h3>{value}</h3></div>
    </div>
  );
}
