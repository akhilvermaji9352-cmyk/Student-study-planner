import { useState } from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { useApp, dateStr } from '../context/AppContext.jsx';

export default function Calendar() {
  const { tasks } = useApp();
  const [view, setView] = useState(new Date());
  const [sel, setSel] = useState(dateStr());
  const y = view.getFullYear(), m = view.getMonth();
  const first = new Date(y, m, 1).getDay();
  const days = new Date(y, m + 1, 0).getDate();
  const cells = [...Array(first).fill(null), ...Array.from({ length: days }, (_, i) => i + 1)];
  const iso = (d) => `${y}-${String(m + 1).padStart(2, '0')}-${String(d).padStart(2, '0')}`;
  const on = (d) => tasks.filter((t) => t.deadline === iso(d));
  const upcoming = tasks.filter((t) => !t.done && t.deadline >= dateStr()).sort((a, b) => a.deadline.localeCompare(b.deadline)).slice(0, 6);

  return (
    <div className="grid-2">
      <div className="card">
        <div className="cal-head">
          <button className="icon-btn" onClick={() => setView(new Date(y, m - 1, 1))}><ChevronLeft size={18} /></button>
          <h3>{view.toLocaleString('default', { month: 'long', year: 'numeric' })}</h3>
          <button className="icon-btn" onClick={() => setView(new Date(y, m + 1, 1))}><ChevronRight size={18} /></button>
        </div>
        <div className="cal-grid">
          {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map((d) => <b key={d} className="muted">{d}</b>)}
          {cells.map((d, i) => d === null ? <span key={i} /> : (
            <button key={i} className={`cal-day ${iso(d) === dateStr() ? 'today' : ''} ${iso(d) === sel ? 'sel' : ''}`} onClick={() => setSel(iso(d))}>
              {d}{on(d).length > 0 && <i className="dot" />}
            </button>
          ))}
        </div>
        <h4 style={{ marginTop: 16 }}>Tasks due on {sel}</h4>
        {tasks.filter((t) => t.deadline === sel).map((t) => <p key={t.id} className="muted">• {t.title} ({t.subject})</p>)}
        {!tasks.some((t) => t.deadline === sel) && <p className="muted">Nothing due.</p>}
      </div>
      <div className="card">
        <h3>Upcoming deadlines</h3>
        {upcoming.length === 0 && <p className="muted">No upcoming deadlines.</p>}
        {upcoming.map((t) => (
          <div key={t.id} className="row"><span>{t.title}<br /><small className="muted">{t.subject}</small></span><span className={`tag p-${t.priority}`}>{t.deadline}</span></div>
        ))}
      </div>
    </div>
  );
}
