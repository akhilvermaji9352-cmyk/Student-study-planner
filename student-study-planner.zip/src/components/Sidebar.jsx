import { NavLink, Link } from 'react-router-dom';
import { LayoutDashboard, ListChecks, CalendarClock, CalendarDays, Timer, BarChart3, User, Settings, BookOpenCheck } from 'lucide-react';

const links = [
  ['/dashboard', 'Dashboard', LayoutDashboard], ['/tasks', 'Tasks', ListChecks], ['/planner', 'Study Planner', CalendarClock],
  ['/calendar', 'Calendar', CalendarDays], ['/timer', 'Pomodoro', Timer], ['/progress', 'Progress', BarChart3],
  ['/profile', 'Profile', User], ['/settings', 'Settings', Settings],
];

export default function Sidebar({ open, close }) {
  return (
    <aside className={`sidebar ${open ? 'open' : ''}`}>
      <Link to="/" className="brand"><BookOpenCheck size={26} /> StudyPlanner</Link>
      <nav>
        {links.map(([to, label, Icon]) => (
          <NavLink key={to} to={to} onClick={close} className={({ isActive }) => (isActive ? 'active' : '')}>
            <Icon size={19} /> {label}
          </NavLink>
        ))}
      </nav>
    </aside>
  );
}
