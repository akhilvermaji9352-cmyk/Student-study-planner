import { Pencil, Trash2, Check, Clock } from 'lucide-react';
import { dateStr } from '../context/AppContext.jsx';

export default function TaskCard({ task, onToggle, onEdit, onDelete }) {
  const overdue = !task.done && task.deadline && task.deadline < dateStr();
  return (
    <div className={`card task ${task.done ? 'done' : ''}`}>
      <button className={`check ${task.done ? 'on' : ''}`} onClick={onToggle} aria-label="Toggle complete">{task.done && <Check size={14} />}</button>
      <div className="task-body">
        <h4>{task.title}</h4>
        <div className="tags">
          <span className="tag">{task.subject}</span>
          <span className={`tag p-${task.priority}`}>{task.priority}</span>
          <span className={`tag ${overdue ? 'p-High' : ''}`}><Clock size={12} /> {task.deadline || 'No deadline'}{overdue && ' (overdue)'}</span>
        </div>
      </div>
      <button className="icon-btn" onClick={onEdit} aria-label="Edit"><Pencil size={16} /></button>
      <button className="icon-btn danger" onClick={onDelete} aria-label="Delete"><Trash2 size={16} /></button>
    </div>
  );
}
