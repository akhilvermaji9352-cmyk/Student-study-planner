import { Menu, Moon, Sun } from 'lucide-react';
import { useApp } from '../context/AppContext.jsx';

export default function Header({ title, toggleMenu }) {
  const { theme, toggleTheme, profile } = useApp();
  return (
    <header className="header">
      <button className="icon-btn menu-btn" onClick={toggleMenu} aria-label="Menu"><Menu size={20} /></button>
      <h2>{title}</h2>
      <div className="header-right">
        <button className="icon-btn" onClick={toggleTheme} aria-label="Toggle theme">{theme === 'light' ? <Moon size={19} /> : <Sun size={19} />}</button>
        <div className="avatar">{profile.name.charAt(0).toUpperCase()}</div>
      </div>
    </header>
  );
}
